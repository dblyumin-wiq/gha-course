# GitHub Actions Udemy Course

This repostitory contains the practice code for the course.
